# সেবালিং বিডি — Flutter MVP
আপনার এলাকার প্রয়োজনীয় সেবা, এখন এক অ্যাপে।

বর্তমানে: demo login, home, area selection, service categories/search, provider list, booking, booking history, profile এবং provider toggle।

Production করতে Firebase/Supabase, real GPS/map, provider onboarding, chat/call, payment, reviews, notifications, admin panel এবং Play Store release যোগ করতে হবে।

Run:
flutter pub get
flutter run
