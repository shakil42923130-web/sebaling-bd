import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
  const App({super.key});
  Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'সেবালিং বিডি',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:const Color(0xff078b4c)),
    home:const Login());
}

class Data extends ChangeNotifier{
  String area='টঙ্গী, গাজীপুর';
  final bookings=<String>[];
  bool provider=false;
  void book(String x){bookings.add(x);notifyListeners();}
  void toggle(){provider=!provider;notifyListeners();}
}
final data=Data();

const cats=[('ইলেকট্রিশিয়ান','⚡'),('প্লাম্বার','🚰'),('AC / ফ্রিজ','❄️'),('পরিষ্কার','🧹'),('মোবাইল / PC','💻'),('গাড়ি / বাইক','🚗'),('ডাক্তার','🏥'),('ফার্মেসি','💊')];
const pros=[('রহিম ইলেকট্রিক','ইলেকট্রিশিয়ান','4.8','৳300 থেকে'),('টঙ্গী প্লাম্বিং','প্লাম্বার','4.7','৳350 থেকে'),('কুল কেয়ার বিডি','AC / ফ্রিজ','4.9','৳500 থেকে'),('স্মার্ট টেক','মোবাইল / PC','4.8','৳200 থেকে')];

class Login extends StatelessWidget{
  const Login({super.key});
  Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Padding(
    padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      Container(width:80,height:80,decoration:BoxDecoration(color:const Color(0xff078b4c),borderRadius:BorderRadius.circular(22)),child:const Center(child:Text('স',style:TextStyle(color:Colors.white,fontSize:42,fontWeight:FontWeight.bold)))),
      const SizedBox(height:18),const Text('সেবালিং বিডি',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),const Text('আপনার এলাকার প্রয়োজনীয় সেবা, এখন এক অ্যাপে।',textAlign:TextAlign.center),
      const SizedBox(height:30),const TextField(decoration:InputDecoration(labelText:'মোবাইল নম্বর',prefixIcon:Icon(Icons.phone),border:OutlineInputBorder())),
      const SizedBox(height:14),SizedBox(width:double.infinity,height:52,child:FilledButton(
        onPressed:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>const Main())),
        child:const Text('শুরু করুন'))),
    ]))));
}

class Main extends StatefulWidget{const Main({super.key});State<Main> createState()=>_Main();}
class _Main extends State<Main>{
  int i=0;
  Widget build(BuildContext c)=>AnimatedBuilder(animation:data,builder:(_,__)=>Scaffold(
    body:IndexedStack(index:i,children:const[Home(),Bookings(),Profile()]),
    bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(v)=>setState(()=>i=v),destinations:const[
      NavigationDestination(icon:Icon(Icons.home_outlined),label:'হোম'),NavigationDestination(icon:Icon(Icons.calendar_month_outlined),label:'বুকিং'),NavigationDestination(icon:Icon(Icons.person_outline),label:'প্রোফাইল')])));}
}

class Home extends StatefulWidget{const Home({super.key});State<Home> createState()=>_Home();}
class _Home extends State<Home>{
  String q='';
  Widget build(BuildContext c){
    final cs=cats.where((x)=>x.$1.toLowerCase().contains(q.toLowerCase())).toList();
    return SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
      Row(children:[Container(width:46,height:46,decoration:BoxDecoration(color:const Color(0xff078b4c),borderRadius:BorderRadius.circular(14)),child:const Center(child:Text('স',style:TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.bold)))),const SizedBox(width:10),const Expanded(child:Text('সেবালিং বিডি',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),IconButton(onPressed:(){},icon:const Icon(Icons.notifications_none))]),
      const SizedBox(height:15),
      InkWell(onTap:()=>showModalBottomSheet(context:c,builder:(_)=>Column(mainAxisSize:MainAxisSize.min,children:[
        const Padding(padding:EdgeInsets.all(18),child:Text('এলাকা নির্বাচন',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),
        for(final a in ['টঙ্গী, গাজীপুর','উত্তরা, ঢাকা','মিরপুর, ঢাকা','গাজীপুর সদর']) ListTile(title:Text(a),onTap:(){data.area=a;Navigator.pop(c);})
      ])),child:Card(child:ListTile(leading:const Icon(Icons.location_on,color:Color(0xff078b4c)),title:const Text('আপনার এলাকা'),subtitle:Text(data.area),trailing:const Icon(Icons.keyboard_arrow_down)))),
      const SizedBox(height:10),
      TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(hintText:'কোন সেবা খুঁজছেন?',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none))),
      const SizedBox(height:20),const Text('সেবাসমূহ',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),
      GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:cs.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:4,crossAxisSpacing:8,mainAxisSpacing:10,childAspectRatio:.82),
        itemBuilder:(_,n)=>InkWell(onTap:()=>book(c,cs[n].$1),child:Column(children:[Container(width:56,height:56,decoration:BoxDecoration(color:Colors.green.shade50,borderRadius:BorderRadius.circular(16)),child:Center(child:Text(cs[n].$2,style:const TextStyle(fontSize:26)))),const SizedBox(height:5),Text(cs[n].$1,textAlign:TextAlign.center,maxLines:2,style:const TextStyle(fontSize:10))]))),
      const SizedBox(height:20),const Text('কাছাকাছি সেবাদাতা',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      ...pros.map((p)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(p.$1),subtitle:Text('${p.$2}\n⭐ ${p.$3} • ${p.$4}'),isThreeLine:true,trailing:FilledButton(onPressed:()=>book(c,p.$1),child:const Text('বুক')))))
    ]));
  }
  void book(BuildContext c,String p){data.book(p);showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('বুকিং সফল'),content:Text('$p-এর কাছে booking request পাঠানো হয়েছে।'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('ঠিক আছে'))]));}
}

class Bookings extends StatelessWidget{const Bookings({super.key});Widget build(BuildContext c)=>SafeArea(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('আমার বুকিং',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:12),Expanded(child:data.bookings.isEmpty?const Center(child:Text('এখনও কোনো বুকিং নেই')):ListView(children:[...data.bookings.map((x)=>Card(child:ListTile(leading:const Icon(Icons.check_circle,color:Colors.green),title:Text(x),subtitle:const Text('অনুরোধ পাঠানো হয়েছে'))))]))]));}

class Profile extends StatelessWidget{const Profile({super.key});Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[const Text('প্রোফাইল',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:16),const Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.person)),title:Text('আমার অ্যাকাউন্ট'),subtitle:Text('মোবাইল নম্বর'))),Card(child:ListTile(leading:const Icon(Icons.engineering),title:const Text('আমি সেবাদাতা হতে চাই'),subtitle:const Text('আপনার সেবা তালিকাভুক্ত করুন'),trailing:Switch(value:data.provider,onChanged:(_)=>data.toggle()))),const Card(child:ListTile(leading:Icon(Icons.help_outline),title:Text('সহায়তা')))]));}
